<?php
$this->load->View('admin/Template_user/header');
$this->load->View('admin/Template_user/navbar');
$this->load->View('admin/Template_user/sidebar');
$this->load->View($content);
$this->load->View('admin/Template_user/footer');
