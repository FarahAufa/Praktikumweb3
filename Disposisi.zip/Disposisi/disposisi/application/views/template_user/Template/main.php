<?php
$this->load->View('template_user/header');
$this->load->View('template_user/navbar');
$this->load->View('template_user/sidebar');
$this->load->View($content);
$this->load->View('template_user/footer');
